#pragma once
#include "Core/EditorState.h"
#include "Core/EditorCamera.h"
#include "Core/AppStateMachine.h"

#include "Panels/ScenePanel.h"
#include "Panels/PropertiesPanel.h"
#include "Panels/ViewportPanel.h"
#include "Panels/NetworkPanel.h"
#include "Panels/ContentBrowser.h"
#include "Panels/TilemapEditorPanel.h"
#include "Panels/SpriteAtlasEditorPanel.h"
#include "Panels/AssetEditorPanel.h"
#include "Panels/ConsolePanel.h"

#include <BoonDebug/Logger.h>

#include "Project/ProjectLoader.h"
#include "Tools/NewProjectDialog.h"

#include "UI/EditorRenderer.h"

#include <Asset/Assets.h>
#include <Asset/AssetRef.h>
#include <Assets/Importer/TextureImporter.h>
#include <Assets/Importer/ShaderImporter.h>
#include <Assets/Importer/SpriteAtlasImporter.h>
#include <Assets/Importer/SceneImporter.h>
#include <Assets/Importer/TilemapImporter.h>

#include "Assets/AssetDirectoryScanner.h"

#include <Core/Application.h>
#include <Core/ServiceLocator.h>
#include <Core/Time.h>
#include <Core/FileSystem.h>

#include <Event/EventBus.h>
#include <Event/SceneEvents.h>
#include "Event/EditorEvent.h"

#include <Renderer/Renderer.h>

#include <Scene/GameObject.h>
#include <Scene/SceneSerializer.h>

#include <Component/NameComponent.h>
#include <Component/CameraComponent.h>
#include <Component/SpriteRendererComponent.h>
#include <Component/SpriteAnimatorComponent.h>
#include <Component/BoxCollider2D.h>
#include <Component/Rigidbody2D.h>

#include <Networking/Components/NetRigidbody2D.h>
#include <Networking/Components/NetTransform.h>
#include <Networking/Events/NetConnectionEvent.h>
#include <Networking/NetIdentity.h>
#include <Networking/NetDriver.h>
#include <Networking/NetScene.h>
#include <Networking/NetRepRegistry.h>
#include <Platform/Steam/SteamNetDriver.h>

#include <Module/ModuleLibrary.h>

#include <Reflection/BClass.h>

#include <BoonDebug/DebugRenderer.h>

#include <Command/EditorCommandQueue.h>

#include <Input/Input.h>

#include <iostream>
#include <imgui.h>

using namespace BoonEditor;

BoonEditor::EditorState::EditorState(const ProjectConfig& project)
{
	m_Context.m_CurrentProject = project;
}

EditorState::~EditorState() = default;

void EditorState::OnEnter()
{
	const RuntimeConfig& config{ m_Context.m_CurrentProject.Runtime };

	Window& window{ Application::Get().GetWindow() };
	AssetLibrary& assetLib{ Assets::Get() };
	
	const std::filesystem::path generatedRoot = config.ProjectRoot / "generated/Assets";
	const std::filesystem::path gameRuntimeRoot = generatedRoot / "Game";
	const std::filesystem::path engineRuntimeRoot = generatedRoot / "Engine";
	const std::filesystem::path editorRuntimeRoot = generatedRoot / "Editor";

	assetLib.SetRuntimeAssetRoot(gameRuntimeRoot);
	assetLib.AddRuntimeAssetRoot(engineRuntimeRoot);
	assetLib.AddRuntimeAssetRoot(editorRuntimeRoot);

	assetLib.LoadManifest(gameRuntimeRoot / "AssetManifest.json");
	assetLib.LoadManifest(engineRuntimeRoot / "AssetManifest.json");
	assetLib.LoadManifest(editorRuntimeRoot / "AssetManifest.json");

	if (!ServiceLocator::Has<AssetImporterRegistry>())
		ServiceLocator::Register<AssetImporterRegistry>();

	AssetImporterRegistry& importer = ServiceLocator::Get<AssetImporterRegistry>();
	importer.ClearAssetRoots();
	importer.AddAssetRoot(config.AssetsRoot, gameRuntimeRoot);
	importer.AddAssetRoot(config.EngineContentRoot, engineRuntimeRoot);
	importer.AddAssetRoot(m_Context.m_CurrentProject.Editor.EditorResourcesRoot, editorRuntimeRoot);
	importer.BindToAssetLibrary(assetLib);

	importer.RegisterImporter<Texture2DImporter>();
	importer.RegisterImporter<ShaderImporter>();
	importer.RegisterImporter<SpriteAtlasImporter>();
	importer.RegisterImporter<SceneImporter>();
	importer.RegisterImporter<TilemapImporter>();

	m_NetworkSettings = Application::Get().GetDescriptor().Network;

	m_PRenderer = std::make_unique<EditorRenderer>(m_Context.m_CurrentProject);

	SceneManager& sceneManager = ServiceLocator::Get<SceneManager>();
	Scene& scene = sceneManager.CreateScene("Game");

	m_Context.CreateObject<AssetDirectoryScanner>(0, 1.f);
	m_Context.CreateObject<AssetDirectoryScanner>(1, 1.f);

	ViewportPanel& viewport = m_Context.CreateWidget<ViewportPanel>("Viewport", &m_SceneContext, &m_SelectionContext);
	viewport.GetToolbar()->BindOnPlayCallback(std::bind(&EditorState::OnBeginPlay, this));
	viewport.GetToolbar()->BindOnStopCallback(std::bind(&EditorState::OnStopPlay, this));

	AssetEditorPanel& assetEditor = m_Context.CreateWidget<AssetEditorPanel>("asset", &viewport);
	assetEditor.RegisterEditor(new TilemapEditorPanel("tilemap", &m_Context));
	assetEditor.RegisterEditor(new SpriteAtlasEditorPanel("sprite atlas", &m_Context));
	m_pSelectedAsset = &assetEditor.GetContext();

	m_Context.CreateWidget<ContentBrowser>("content", m_pSelectedAsset);
	m_Context.CreateWidget<PropertiesPanel>("properties", &m_SelectionContext);
	m_Context.CreateWidget<ScenePanel>("scene",  &m_SceneContext, &m_SelectionContext);
	m_Context.CreateWidget<NetworkPanel>("network", m_NetworkSettings);
	m_Context.CreateWidget<ConsolePanel>("console");

	m_Context.CreateWidget<NewProjectDialog>("NewProject");

	EventBus& eventBus = ServiceLocator::Get<EventBus>();
	std::shared_ptr<NetDriver> network = std::make_shared<SteamNetDriver>();
	ServiceLocator::Register<NetDriver>(network);

	m_SceneContext.Set(&scene);
	m_pSelectedScene = &scene;

	m_SceneChangedEvent = eventBus.Subscribe<SceneChangedEvent>([this](const SceneChangedEvent& e)
		{
			SceneManager& sceneManager = ServiceLocator::Get<SceneManager>();
			Scene& scene = sceneManager.GetActiveScene();
			m_SceneContext.Set(&scene);
		});

	m_StateChangedEvent = eventBus.Subscribe<EditorPlayStateChangeEvent>([&viewport](const EditorPlayStateChangeEvent& e)
		{
			switch (e.State)
			{
			case EditorPlayState::Play:
				viewport.GetCamera().SetActive(false);
				break;
			case EditorPlayState::Edit:
				viewport.GetCamera().SetActive(true);
				break;
			}
		});

	m_SelectionContext.AddOnContextChangedCallback([this](GameObject obj)
		{
			if (obj.GetScene() == m_pSelectedScene)
				m_Context.GetWidget<ViewportPanel>("Viewport").SetContext(&m_SceneContext);
		});

	std::shared_ptr<ModuleLibrary> moduleLib = std::make_shared<ModuleLibrary>();
	ServiceLocator::Register<ModuleLibrary>(moduleLib);
	ModuleContext ctx{};
	ctx.BClasses = &BClassRegistry::Get();
	ctx.NetReps = &NetRepRegistry::Get();
	ctx.ServiceRegistry = ServiceLocator::GetRegistry();
	moduleLib->LoadModule(config.ProjectRoot / config.IntermediateRoot / config.GameModule / (config.GameModule + ".dll"), ctx);

	SceneSerializer serializer(scene);
	serializer.Deserialize(config.AssetsRoot / config.StartupScene);

	sceneManager.SetActiveScene(scene.GetID(), false);

	Application::Get().GetWindow().SetTitle(m_Context.m_CurrentProject.Runtime.Window.Title);
	BOON_LOG("Project loaded {} : {}", m_Context.m_CurrentProject.Name, m_Context.m_CurrentProject.Runtime.ProjectRoot.string());
}

void EditorState::OnUpdate()
{
	Boon::DebugRenderer::Get().BeginFrame();

	ServiceLocator::Get<NetDriver>().Update();

	Time& time = Boon::Time::Get();
	SceneManager& sceneManager = ServiceLocator::Get<SceneManager>();

	switch (m_PlayState)
	{
		case EditorPlayState::Play:
		{
			while (time.FixedStep())
			{
				sceneManager.FixedUpdate();
			}
		}
	}

	sceneManager.Update();

	for (auto& pObject : m_Context.m_Objects)
	{
		pObject->Update();
	}

	Input& input = ServiceLocator::Get<Input>();
	if (input.IsKeyHeld(Boon::Key::LeftControl)
		&& input.IsKeyPressed(Boon::Key::Z))
	{
		m_Context.GetCommandQueue()->RequestUndo();
	}

	OnRender();

	m_Context.GetCommandQueue()->Execute();
}

void EditorState::OnExit()
{
	EventBus& eventBus = ServiceLocator::Get<EventBus>();
	eventBus.Unsubscribe<SceneChangedEvent>(m_SceneChangedEvent);
	eventBus.Unsubscribe<EditorPlayStateChangeEvent>(m_StateChangedEvent);

	ServiceLocator::Get<NetDriver>().Shutdown();

	ModuleContext ctx{};
	ctx.BClasses = &BClassRegistry::Get();
	ctx.NetReps = &NetRepRegistry::Get();
	ctx.ServiceRegistry = ServiceLocator::GetRegistry();
	ServiceLocator::Get<ModuleLibrary>().UnloadAll(ctx);

	SceneManager& sceneManager = ServiceLocator::Get<SceneManager>();
	sceneManager.UnloadAll();

	Assets::Get().ClearCache();
	Assets::Get().ClearRegistry();

	AssetDatabase::Get().Clear();
}

void EditorState::OnRender()
{
	m_PRenderer->BeginFrame();

	m_DragDrop.Clear();

	ImGui::BeginMainMenuBar();
	if (ImGui::BeginMenu("Project"))
	{
		if (ImGui::MenuItem("New Project"))
		{
			if (m_PlayState == EditorPlayState::Play)
			{
				OnStopPlay();
			}
			NewProjectDialog* pDialog = m_Context.TryGetWidget<NewProjectDialog>("NewProject");
			if (pDialog) pDialog->Open();
		}
		if (ImGui::MenuItem("Open Project"))
		{
			if (m_PlayState == EditorPlayState::Play)
			{
				OnStopPlay();
			}
			FileSystem::OpenDialogOptions options{};
			options.filters = { FileSystem::FileFilter{ L"Boon Project", L"*.bproj" } };
			options.title = L"Open Project";
			FileSystem::Path projPath = FileSystem::OpenFileDialog(options);

			if (!projPath.empty())
			{
				auto projectFile = ProjectLoader::LoadFromFile(projPath);
				Application::Get().GetStateMachine()->RequestStateChange(std::make_shared<EditorState>(projectFile.Value));
			}
		}
		ImGui::EndMenu();
	}
	if (ImGui::BeginMenu("File"))
	{
		if (ImGui::MenuItem("New scene"))
		{
			if (m_PlayState != EditorPlayState::Play)
			{
				SceneManager& sceneManager = ServiceLocator::Get<SceneManager>();
				m_SceneContext.Set(&sceneManager.CreateScene("New Scene"));
				m_pSelectedScene = m_SceneContext.Get();

				sceneManager.SetActiveScene(m_SceneContext.Get()->GetID());
			}
		}
		if (ImGui::MenuItem("Save scene"))
		{
			if (m_PlayState != EditorPlayState::Play)
			{
				FileSystem::OpenDialogOptions options{};
				options.filters = { FileSystem::FileFilter{ L"Boon Project", L"*.scene" } };
				options.title = L"Save Scene";
				options.initialPath = m_Context.m_CurrentProject.Runtime.AssetsRoot;
				FileSystem::Path scenPath = FileSystem::OpenFileDialog(options);

				if (!scenPath.empty())
				{
					SceneSerializer serializer(*m_pSelectedScene);
					serializer.Serialize(scenPath);
				}
			}
		}
		if (ImGui::MenuItem("Open scene"))
		{
			if (m_PlayState != EditorPlayState::Play)
			{
				FileSystem::OpenDialogOptions options{};
				options.filters = { FileSystem::FileFilter{ L"Boon Scene", L"*.scene" } };
				options.title = L"Open Scene";
				options.initialPath = m_Context.m_CurrentProject.Runtime.AssetsRoot;
				FileSystem::Path scenPath = FileSystem::OpenFileDialog(options);

				if (!scenPath.empty())
				{
					SceneManager& sceneManager = ServiceLocator::Get<SceneManager>();
					m_SceneContext.Set(&sceneManager.CreateScene("New Scene"));
					m_pSelectedScene = m_SceneContext.Get();

					SceneSerializer serializer(*m_SceneContext.Get());
					serializer.Deserialize(scenPath);

					sceneManager.SetActiveScene(m_SceneContext.Get()->GetID(), false);
				}
			}
		}
		ImGui::EndMenu();
	}
	ImGui::EndMainMenuBar();
	
	for (auto& [name, pPanel] : m_Context.m_Widgets)
	{
		pPanel->RenderUI();
	}
	
	m_DragDrop.Process();
	m_PRenderer->EndFrame();
}

void EditorState::OnBeginPlay()
{
	StartNetwork();

	m_PlayState = EditorPlayState::Play;
	SceneManager& sceneManager = ServiceLocator::Get<SceneManager>();

	m_Context.GetWidget<ViewportPanel>("Viewport").SetContext(&m_SceneContext);

	m_SceneContext.Set(&sceneManager.CreateScene("PlayScene"));
	SceneSerializer serializer(*m_SceneContext.Get());
	serializer.Copy(*m_pSelectedScene);
	sceneManager.SetActiveScene(m_SceneContext.Get()->GetID());
	
	EventBus& eventBus = ServiceLocator::Get<EventBus>();
	eventBus.Post(EditorPlayStateChangeEvent(m_PlayState));
}

void EditorState::OnStopPlay()
{
	StopNetwork();

	m_PlayState = EditorPlayState::Edit;
	SceneManager& sceneManager = ServiceLocator::Get<SceneManager>();

	SceneID sceneId = m_SceneContext.Get()->GetID();
	m_SceneContext.Set(m_pSelectedScene);
	sceneManager.SetActiveScene(m_SceneContext.Get()->GetID(), false);
	sceneManager.UnloadScene(sceneId);

	EventBus& eventBus = ServiceLocator::Get<EventBus>();
	eventBus.Post(EditorPlayStateChangeEvent(m_PlayState));
}

void EditorState::StartNetwork()
{
	EventBus& eventBus = ServiceLocator::Get<EventBus>();
	NetDriver& network = ServiceLocator::Get<NetDriver>();

	network.Initialize(m_NetworkSettings);
	if (!network.IsStandalone())
	{
		network.BindOnConnectedCallback([this](NetConnection* pConnection) {OnConnected(pConnection); });
		network.BindOnDisconnectedCallback([this](NetConnection* pConnection) {OnDisconnected(pConnection); });
		network.BindOnPacketCallback([this](NetConnection* pConnection, NetPacket& packet) { OnPacketReceived(pConnection, packet); });

		m_BindNetSceneHandle = ServiceLocator::Get<SceneManager>().BindOnSceneChanged([](Scene& e)
			{
				Scene& scene = ServiceLocator::Get<SceneManager>().GetActiveScene();
				auto& network = ServiceLocator::Get<NetDriver>();
				auto pScene{ std::make_shared<NetScene>(&scene, &network) };
				network.BindScene(pScene);
			});

		//m_BindNetSceneEvent = eventBus.Subscribe<SceneChangedEvent>([](Scene& e)
		//	{
		//		Scene& scene = ServiceLocator::Get<SceneManager>().GetActiveScene();
		//		auto& network = ServiceLocator::Get<NetDriver>();
		//		auto pScene{ std::make_shared<NetScene>(&scene, &network) };
		//		network.BindScene(pScene);
		//	});

		if (network.IsClient())
		{
			network.Connect(m_NetworkSettings.Ip.c_str(), m_NetworkSettings.Port);
		}

		NetworkPanel& net = m_Context.GetWidget<NetworkPanel>("network");
		net.SetDriver(&network);
	}
}

void EditorState::StopNetwork()
{
	NetworkPanel& net = m_Context.GetWidget<NetworkPanel>("network");
	net.SetDriver(nullptr);

	ServiceLocator::Get<SceneManager>().UnbindOnSceneChanged(m_BindNetSceneHandle);
	
	NetDriver& network = ServiceLocator::Get<NetDriver>();
	network.Shutdown();
}

void EditorState::OnConnected(NetConnection* pConnection)
{
	EventBus& eventBus = ServiceLocator::Get<EventBus>();
	eventBus.Post(Boon::NetConnectionEvent(pConnection->GetId(), Boon::ENetConnectionState::Connected));
}

void EditorState::OnDisconnected(NetConnection* pConnection)
{
	EventBus& eventBus = ServiceLocator::Get<EventBus>();
	eventBus.Post(Boon::NetConnectionEvent(pConnection->GetId(), Boon::ENetConnectionState::Disconnected));
}

void EditorState::OnPacketReceived(NetConnection* pConnection, NetPacket& packet)
{

}