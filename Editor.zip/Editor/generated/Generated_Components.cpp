// Automatically generated. Do not modify.
#include "Reflection/RegisterBClass.h"
#include "Reflection/BClass.h"
#include "Networking/NetRepRegistry.h"

#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/BoxCollider2D.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/CameraComponent.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/NameComponent.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/Rigidbody2D.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/SpriteAnimatorComponent.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/SpriteRendererComponent.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/TextureRendererComponent.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/TilemapRendererComponent.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Component/TransformComponent.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Networking/Components/NetRigidbody2D.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Networking/Components/NetRigidbody2DSerializer.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Networking/Components/NetTransform.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Networking/Components/NetTransformSerializer.h"
#include "D:/Projects/BoonEngine/Boon-Engine/Boon/include/Networking/NetIdentity.h"

namespace Boon {

void RegisterGeneratedClasses_Editor(BClassRegistry& classRegistry, NetRepRegistry& netRegistry)
{
    // Boon::BoxCollider2D
    {
        BClass* cls = RegisterBClass<Boon::BoxCollider2D>(classRegistry, "BoxCollider2D");
        cls->AddPropertyOffset("Size", "glm::vec2", offsetof(Boon::BoxCollider2D, Size), sizeof(glm::vec2), BTypeId::Float2);
        cls->AddPropertyOffset("Density", "float", offsetof(Boon::BoxCollider2D, Density), sizeof(float), BTypeId::Float);
        cls->AddPropertyOffset("Friction", "float", offsetof(Boon::BoxCollider2D, Friction), sizeof(float), BTypeId::Float);
        cls->AddPropertyOffset("Restitution", "float", offsetof(Boon::BoxCollider2D, Restitution), sizeof(float), BTypeId::Float);
        cls->AddPropertyOffset("IsTrigger", "bool", offsetof(Boon::BoxCollider2D, IsTrigger), sizeof(bool), BTypeId::Bool);
        cls->AddMeta("Name", "Box Collider 2D");
    }
    // Boon::CameraComponent
    {
        BClass* cls = RegisterBClass<Boon::CameraComponent>(classRegistry, "CameraComponent");
        cls->AddPropertyOffset("Camera", "Camera", offsetof(Boon::CameraComponent, Camera), sizeof(Camera), BTypeId::UserDefined);
        cls->AddPropertyOffset("Active", "bool", offsetof(Boon::CameraComponent, Active), sizeof(bool), BTypeId::Bool);
        cls->AddMeta("Name", "Camera");
        cls->AddMeta("HideInInspector");
    }
    // Boon::NameComponent
    {
        BClass* cls = RegisterBClass<Boon::NameComponent>(classRegistry, "NameComponent");
        cls->AddPropertyOffset("Name", "std::string", offsetof(Boon::NameComponent, Name), sizeof(std::string), BTypeId::String);
        cls->AddMeta("HideInInspector");
    }
    // Boon::Rigidbody2D
    {
        BClass* cls = RegisterBClass<Boon::Rigidbody2D>(classRegistry, "Rigidbody2D");
        cls->AddPropertyOffset("Type", "int", offsetof(Boon::Rigidbody2D, Type), sizeof(int), BTypeId::Int);
        cls->AddPropertyOffset("GravityScale", "float", offsetof(Boon::Rigidbody2D, GravityScale), sizeof(float), BTypeId::Float);
        cls->AddPropertyOffset("FixedRotation", "bool", offsetof(Boon::Rigidbody2D, FixedRotation), sizeof(bool), BTypeId::Bool);
        cls->AddPropertyOffset("LinearDamping", "float", offsetof(Boon::Rigidbody2D, LinearDamping), sizeof(float), BTypeId::Float);
        cls->AddPropertyOffset("AngularDamping", "float", offsetof(Boon::Rigidbody2D, AngularDamping), sizeof(float), BTypeId::Float);
        cls->AddPropertyOffset("Mass", "float", offsetof(Boon::Rigidbody2D, Mass), sizeof(float), BTypeId::Float);
    }
    // Boon::SpriteAnimatorComponent
    {
        BClass* cls = RegisterBClass<Boon::SpriteAnimatorComponent>(classRegistry, "SpriteAnimatorComponent");
        cls->AddPropertyOffset("Clip", "int", offsetof(Boon::SpriteAnimatorComponent, Clip), sizeof(int), BTypeId::Int, { BPropertyMeta{ "RangeMin", "0" }, BPropertyMeta{ "RangeMax", "10" }, BPropertyMeta{ "Slider", "" } });
        cls->AddPropertyOffset("pRenderer", "BRef<SpriteRendererComponent>", offsetof(Boon::SpriteAnimatorComponent, pRenderer), sizeof(BRef<SpriteRendererComponent>), BTypeId::BRef);
        cls->AddMeta("Category", "Components");
        cls->AddMeta("Name", "Sprite animator");
    }
    // Boon::SpriteRendererComponent
    {
        BClass* cls = RegisterBClass<Boon::SpriteRendererComponent>(classRegistry, "SpriteRendererComponent");
        cls->AddPropertyOffset("Color", "glm::vec4", offsetof(Boon::SpriteRendererComponent, Color), sizeof(glm::vec4), BTypeId::Float4, { BPropertyMeta{ "ColorPicker", "" } });
        cls->AddPropertyOffset("Tiling", "float", offsetof(Boon::SpriteRendererComponent, Tiling), sizeof(float), BTypeId::Float);
        cls->AddPropertyOffset("SpriteAtlasHandle", "AssetRef<SpriteAtlasAsset>", offsetof(Boon::SpriteRendererComponent, SpriteAtlasHandle), sizeof(AssetRef<SpriteAtlasAsset>), BTypeId::AssetRef);
        cls->AddPropertyOffset("Sprite", "int", offsetof(Boon::SpriteRendererComponent, Sprite), sizeof(int), BTypeId::Int, { BPropertyMeta{ "Slider", "" }, BPropertyMeta{ "RangeMin", "0" }, BPropertyMeta{ "RangeMax", "10" } });
        cls->AddMeta("Name", "Sprite renderer");
    }
    // Boon::TextureRendererComponent
    {
        BClass* cls = RegisterBClass<Boon::TextureRendererComponent>(classRegistry, "TextureRendererComponent");
        cls->AddPropertyOffset("Color", "glm::vec4", offsetof(Boon::TextureRendererComponent, Color), sizeof(glm::vec4), BTypeId::Float4, { BPropertyMeta{ "ColorPicker", "" } });
        cls->AddPropertyOffset("Tiling", "float", offsetof(Boon::TextureRendererComponent, Tiling), sizeof(float), BTypeId::Float);
        cls->AddPropertyOffset("Texture", "AssetRef<Texture2DAsset>", offsetof(Boon::TextureRendererComponent, Texture), sizeof(AssetRef<Texture2DAsset>), BTypeId::AssetRef);
        cls->AddMeta("Name", "Texture renderer");
    }
    // Boon::TilemapRendererComponent
    {
        BClass* cls = RegisterBClass<Boon::TilemapRendererComponent>(classRegistry, "TilemapRendererComponent");
        cls->AddPropertyOffset("tilemap", "AssetRef<TilemapAsset>", offsetof(Boon::TilemapRendererComponent, tilemap), sizeof(AssetRef<TilemapAsset>), BTypeId::AssetRef);
        cls->AddMeta("Name", "Tilemap renderer");
    }
    // Boon::TransformComponent
    {
        BClass* cls = RegisterBClass<Boon::TransformComponent>(classRegistry, "TransformComponent");
        cls->AddPropertyOffset("m_LocalPosition", "glm::vec3", offsetof(Boon::TransformComponent, m_LocalPosition), sizeof(glm::vec3), BTypeId::Float3, { BPropertyMeta{ "HideInInspector", "" } });
        cls->AddPropertyOffset("m_LocalEuler", "glm::vec3", offsetof(Boon::TransformComponent, m_LocalEuler), sizeof(glm::vec3), BTypeId::Float3, { BPropertyMeta{ "HideInInspector", "" } });
        cls->AddPropertyOffset("m_LocalScale", "glm::vec3", offsetof(Boon::TransformComponent, m_LocalScale), sizeof(glm::vec3), BTypeId::Float3, { BPropertyMeta{ "HideInInspector", "" } });
        cls->AddMeta("HideInInspector");
    }
    // Boon::NetRigidbody2D
    {
        BClass* cls = RegisterBClass<Boon::NetRigidbody2D>(classRegistry, "NetRigidbody2D");
        netRegistry.Register(cls, new NetRigidbody2DSerializer());
    }
    // Boon::NetTransform
    {
        BClass* cls = RegisterBClass<Boon::NetTransform>(classRegistry, "NetTransform");
        netRegistry.Register(cls, new NetTransformSerializer());
    }
    // Boon::NetIdentity
    {
        RegisterBClass<Boon::NetIdentity>(classRegistry, "NetIdentity");
    }
}

void UnregisterGeneratedClasses_Editor(BClassRegistry& classRegistry, NetRepRegistry& netRegistry)
{
    classRegistry.Unregister<Boon::NetIdentity>();
    netRegistry.Unregister<Boon::NetTransform>();
    classRegistry.Unregister<Boon::NetTransform>();
    netRegistry.Unregister<Boon::NetRigidbody2D>();
    classRegistry.Unregister<Boon::NetRigidbody2D>();
    classRegistry.Unregister<Boon::TransformComponent>();
    classRegistry.Unregister<Boon::TilemapRendererComponent>();
    classRegistry.Unregister<Boon::TextureRendererComponent>();
    classRegistry.Unregister<Boon::SpriteRendererComponent>();
    classRegistry.Unregister<Boon::SpriteAnimatorComponent>();
    classRegistry.Unregister<Boon::Rigidbody2D>();
    classRegistry.Unregister<Boon::NameComponent>();
    classRegistry.Unregister<Boon::CameraComponent>();
    classRegistry.Unregister<Boon::BoxCollider2D>();
}
} // namespace Boon
