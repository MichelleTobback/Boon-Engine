#pragma once

#include "EditorPanel.h"
#include "Core/BoonEditor.h"
#include "Panels/ViewportToolbar.h"
#include "Panels/IViewportCanvasRenderer.h"

#include "Core/EditorCamera.h"

#include "DebugRenderer/EditorViewportSettings.h"

#include <Scene/GameObject.h>

#include <memory>

#include <glm/glm.hpp>

namespace Boon
{
    class Scene;
    class SceneRenderer;
}

namespace BoonEditor
{
    class DebugRenderer;

    class ViewportPanel final : public EditorPanel
    {
    public:
        ViewportPanel(
            const std::string& name,
            EditorContext* pContext,
            SceneContext* pSceneContext,
            GameObjectContext* pSelectionContext);

        virtual ~ViewportPanel();

        virtual void Update() override;

        inline ViewportToolbar* GetToolbar() const { return m_pToolbar.get(); }

        inline EditorCamera& GetCamera() { return m_Camera; }

        inline EditorViewportSettings& GetSettings() { return m_Settings; }
        inline const EditorViewportSettings& GetSettings() const { return m_Settings; }

        void SetContext(SceneContext* pContext);

        void SetCanvasRenderer(IViewportCanvasRenderer* renderer);
        void ClearCanvasRenderer(IViewportCanvasRenderer* renderer = nullptr);

        inline bool HasCanvasRenderer() const { return m_pCanvasRenderer != nullptr; }

        inline const glm::vec2& GetSize() const { return m_ViewportSize; }
        inline const glm::vec2& GetMousePosition() const { return m_MousePosition; }

        inline SceneRenderer* GetRenderer() const { return m_pRenderer.get(); }

    protected:
        virtual void OnRenderUI() override;

    private:
        void CameraSettings(float posX, float posY, float maxWidth);
        void VisibilitySettings(float posX, float posY, float maxWidth);

        ViewportCanvasContext CreateCanvasContext() const;

    private:
        std::unique_ptr<SceneRenderer> m_pRenderer;
        EditorCamera m_Camera{ 0.0f, 0.0f };

        bool m_ViewportFocused = false;
        bool m_ViewportHovered = false;

        glm::vec2 m_ViewportSize{ 0.0f, 0.0f };
        glm::vec2 m_ViewportBounds[2];
        glm::vec2 m_MousePosition{};
        glm::vec2 m_ViewportImagePosition{};

        GameObject m_HoveredGameObject{};

        SceneContext* m_pSceneContext = nullptr;
        GameObjectContext* m_pSelectionContext = nullptr;

        std::unique_ptr<ViewportToolbar> m_pToolbar{};
        std::unique_ptr<DebugRenderer> m_pDebugRenderer{};

        EditorViewportSettings m_Settings{};

        IViewportCanvasRenderer* m_pCanvasRenderer = nullptr;
    };
}